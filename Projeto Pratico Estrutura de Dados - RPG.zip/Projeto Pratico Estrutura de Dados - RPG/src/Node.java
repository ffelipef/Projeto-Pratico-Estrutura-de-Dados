public class Node <T> {
    public Node <T> head;
    public Node <T> tail;
    public T data;

    public Node (T data){
        this.data = data;
        this.head = null;
        this.tail = null;
    }

    public Node <T> getHead() {
        return head;
    }

    public void setHead(Node <T> head) {
        this.head = head;
    }

    public Node <T> getTail() {
        return tail;
    }

    public void setTail(Node <T> tail) {
        this.tail = tail;
    }


}
