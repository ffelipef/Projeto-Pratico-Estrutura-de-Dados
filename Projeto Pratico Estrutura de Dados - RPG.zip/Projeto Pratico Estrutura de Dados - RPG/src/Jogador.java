import java.util.Scanner;

public class Jogador{
    private String idJogador;
    private String nomeJogador;
    private String senhaJogador;
    private int saldoMoedas;
    private ListaEncadeada<Personagem> personagens;


    public String getIdJogador() {
        return idJogador;
    }

    public void setIdJogador(String idJogador) {
        this.idJogador = idJogador;
    }

    public String getNomeJogador() {
        return nomeJogador;
    }

    public void setNomeJogador(String nomeJogador) {
        this.nomeJogador = nomeJogador;
    }

    public String getSenhaJogador() {
        return senhaJogador;
    }

    public void setSenhaJogador(String senhaJogador) {
        this.senhaJogador = senhaJogador;
    }

    public int getSaldoMoedas() {
        return saldoMoedas;
    }

    public void setSaldoMoedas(int saldoMoedas) {
        this.saldoMoedas = saldoMoedas;
    }

    public ListaEncadeada<Personagem> getPersonagens() {
        return personagens;
    }

    public void setPersonagens(ListaEncadeada<Personagem> personagens) {
        this.personagens = personagens;
    }

    public Jogador (String nome, String senha){
        this.nomeJogador = nome;
        this.senhaJogador = senha;
        this.personagens = new ListaEncadeada<>();
    }



    public void addPersonagem(Scanner scan){
        System.out.println("nome do personagem: ");
        String nome = scan.nextLine();
        Personagem p = new Personagem(nome);
        personagens.adicionar(p);
        System.out.println("personagem "+nome+" adicionado com sucesso!");
    }

    public Jogador autenticar(Scanner scanner, ListaEncadeada<Jogador> listaJogadores) {
        System.out.print("nome: ");
        String nomeDigitado = scanner.nextLine();
        System.out.print("senha: ");
        String senhaDigitada = scanner.nextLine();

        Node<Jogador> atual = listaJogadores.getPrimeiro();
        while (atual != null) {
            Jogador j = atual.data;
            if (j.nomeJogador.equals(nomeDigitado) && j.senhaJogador.equals(senhaDigitada)) {
                System.out.println("login bem-sucedido!");
                return j;
            }
            atual = atual.head;
        }

        System.out.println("Usuário ou senha incorretos.");
        return null;
    }

    public Personagem selecionarPersonagem(Scanner scan){
        Node<Personagem> atual = personagens.getPrimeiro();
        int cont = 1;

        if (atual == null){
            System.out.println("crie um personagem primeiro");
            return null;
        }
        System.out.println("escolha um personagem:");
        while (atual != null) {
            System.out.println(cont + ". " + atual.data.getNome());
            atual = atual.head;
            cont++;
        }

        int escolha = scan.nextInt();
        scan.nextLine();

        atual = personagens.getPrimeiro();
        for (int i = 1; i < escolha; i++) {
            atual = atual.head;
        }
        return atual.data;
    }

    public void cadastrar(Scanner scan, ListaEncadeada<Jogador> listaJogadores) {
        System.out.print("digite seu nome: ");
        this.nomeJogador = scan.nextLine();
        System.out.print("digite sua senha: ");
        this.senhaJogador = scan.nextLine();
        listaJogadores.adicionar(this);
        System.out.println("cadastro finalizado com sucesso!");
    }
}