public class Itens {
    private String id;
    private String nome;
    private int custoDet;
    private int efeito;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCustoDet() {
        return custoDet;
    }

    public void setCustoDet(int custoDet) {
        this.custoDet = custoDet;
    }

    public int getEfeito() {
        return efeito;
    }

    public void setEfeito(int efeito) {
        this.efeito = efeito;
    }

    public void pocaoVida(Personagem p, Personagem a, int efeito){
        setCustoDet(2);
        setEfeito(efeito);
        p.setDet(p.getDet()-getCustoDet());
        a.curarVida(efeito);
    }

    public void pocaoDano(Personagem p, Personagem a, int efeito){
        setCustoDet(2);
        setEfeito(efeito);
        p.setDet(p.getDet()-getCustoDet());
        a.receberDano(efeito);
    }


}
