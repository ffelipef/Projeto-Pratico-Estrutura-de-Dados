public class ListaEncadeada <T> {
    private Node <T> primeiro;

    public Node<T> getPrimeiro() {
        return primeiro;
    }

    public void setPrimeiro(Node<T> primeiro) {
        this.primeiro = primeiro;
    }

    public ListaEncadeada(){
        this.primeiro = null;
    }

    public void adicionar (T elemento){
        Node<T> novo = new Node<>(elemento);
        if (primeiro == null) {
            primeiro = novo;
        } else {
            Node<T> atual = primeiro;
            while (atual.head != null) {
                atual = atual.head;
            }
            atual.head = novo;
        }
    }

    public boolean remover(T elemento){
        if (primeiro == null){
            return false;
        }

        if (primeiro.data.equals(elemento)) {
            primeiro = primeiro.head;
            return true;
        }

        Node<T> atual = primeiro;
        while (atual.head != null && !atual.head.data.equals(elemento)) {
            atual = atual.head;
        }

        if (atual.head != null) {
            atual.head = atual.head.head;
            return true;
        }

        return false;
        
    }

    public void print(){
        Node<T> atual = primeiro;
        while(atual != null){
            System.out.println(atual.data);
            atual= atual.head;
        }
    }

    public void isEmpty(){
        if (primeiro.head == null){
            System.out.println("ta vazio aq");
        }
    }
}
