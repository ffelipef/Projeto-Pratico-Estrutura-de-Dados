public class Personagem {
    private String id;
    private String nome;
    private String nivel;
    private int pv;
    private int det;
    private ListaEncadeada<Itens> inventario;

    public Personagem (String nome){
        this.nome = nome;
    }
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getNivel() {
        return nivel;
    }
    public void setNivel(String nivel) {
        this.nivel = nivel;
    }
    public int getPv() {
        return pv;
    }
    public void setPv(int pv) {
        this.pv = pv;
    }
    public int getDet() {
        return det;
    }
    public void setDet(int det) {
        this.det = det;
    }
    public ListaEncadeada<Itens> getInventario() {
        return inventario;
    }
    public void setInventario(ListaEncadeada<Itens> inventario) {
        this.inventario = inventario;
    }


    public void receberDano(int dano){
        setPv(getPv()-dano);
        System.out.println("o personagem "+this.nome+" recebeu "+dano+" pontos de dano\nele está com "+getPv()+" pontos de vida");
    }

    public void curarVida(int valor){
        setPv(getPv()+valor);
        System.out.println("o personagem "+this.nome+" recebeu "+valor+" pontos de vida\nele está com "+getPv()+" pontos de vida");
    }

    public boolean estaVivo(){
        return getPv()>0;
    }
}
